<?php
session_start();
include("config/controller.php");

// Get counts from database
$total_books = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as count FROM buku"))['count'];
$total_categories = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as count FROM kategori"))['count'];
$total_users = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as count FROM login WHERE level = 'user'"))['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>E-Library Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Animate.css -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
  :root {
    --k-primary: #2c3e50;    /* Deep Blue */
    --k-black: #1a1a1a;      /* Darker Background */
    --k-dark: #34495e;       /* Card/section BG */
    --k-gray: #7f8c8d;       /* Nav/secondary BG */
    --k-light: #ecf0f1;      /* Table stripes, light BG */
    --k-white: #ffffff;      /* White */
    --k-blue: #3498db;       /* Accent Blue */
    --k-gold: #f1c40f;       /* Warm Gold */
    --k-text: #ecf0f1;       /* Off-white text */
    --k-accent: #e74c3c;     /* Accent Red */
    --k-success: #2ecc71;    /* Success Green */
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  body {
    background-color: var(--k-black);
    color: var(--k-text);
    overflow-x: hidden;
  }

  .navbar {
    background-color: var(--k-primary);
    animation: slideDown 0.6s ease-in-out;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
  }

  @keyframes slideDown {
    from { transform: translateY(-100%); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }

  .navbar-brand, .nav-link {
    color: var(--k-white) !important;
    transition: var(--transition);
  }

  .nav-link:hover {
    color: var(--k-gold) !important;
    transform: translateY(-2px);
  }

  .carousel-caption {
    background-color: rgba(44, 62, 80, 0.8);
    padding: 20px;
    border-radius: 15px;
    backdrop-filter: blur(5px);
    transform: translateY(20px);
    opacity: 0;
    transition: all 0.5s ease;
    border: 1px solid var(--k-blue);
  }

  .carousel-item.active .carousel-caption {
    transform: translateY(0);
    opacity: 1;
  }

  .card {
    background-color: var(--k-dark);
    color: var(--k-text);
    border: 1px solid var(--k-blue);
    transition: var(--transition);
    cursor: pointer;
  }

  .card-hover:hover {
    box-shadow: 0 0 20px rgba(52, 152, 219, 0.3);
    transform: translateY(-10px) scale(1.02);
    border-color: var(--k-gold);
  }

  .btn-primary {
    background-color: var(--k-blue);
    color: var(--k-white);
    border: none;
    transition: var(--transition);
    position: relative;
    overflow: hidden;
  }

  .btn-primary:hover {
    background-color: var(--k-gold);
    box-shadow: 0 0 15px var(--k-blue);
    color: var(--k-primary);
    transform: translateY(-2px);
  }

  .btn-primary::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
  }

  .btn-primary:hover::after {
    width: 300px;
    height: 300px;
  }

  .form-control {
    background-color: var(--k-dark);
    color: var(--k-white);
    border: 1px solid var(--k-blue);
    transition: var(--transition);
  }

  .form-control:focus {
    box-shadow: 0 0 15px rgba(52, 152, 219, 0.3);
    border-color: var(--k-gold);
  }

  .form-control::placeholder {
    color: var(--k-gray);
  }

  .carousel {
    width: 100%;
    height: 500px;
    overflow: hidden;
    position: relative;
  }

  .carousel img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
  }

  .carousel-item:hover img {
    transform: scale(1.05);
  }

  .typing-text {
    border-right: 2px solid var(--k-blue);
    white-space: nowrap;
    overflow: hidden;
    animation: typing 3.5s steps(40, end), blink-caret 0.75s step-end infinite;
  }

  @keyframes typing {
    from { width: 0 }
    to { width: 100% }
  }

  @keyframes blink-caret {
    from, to { border-color: transparent }
    50% { border-color: var(--k-blue) }
  }

  .floating-btn {
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 60px;
    height: 60px;
    background: var(--k-blue);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--k-white);
    font-size: 24px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    transition: all 0.3s ease;
    z-index: 1000;
  }

  .floating-btn:hover {
    transform: translateY(-5px) rotate(360deg);
    background: var(--k-gold);
    color: var(--k-primary);
  }

  .search-container {
    position: relative;
    transition: all 0.3s ease;
  }

  .search-container:focus-within {
    transform: scale(1.02);
  }

  .search-icon {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--k-blue);
  }

  .pulse {
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
  }

  .display-5 {
    color: var(--k-gold);
    font-weight: bold;
  }

  .lead {
    color: var(--k-text);
  }

  .card-title {
    color: var(--k-gold);
  }

  .card-text {
    color: var(--k-text);
  }

  .stat-card {
    background: var(--k-dark);
    border-radius: 15px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    border: 1px solid var(--k-blue);
    transition: var(--transition);
    position: relative;
    overflow: hidden;
  }

  .stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(52, 152, 219, 0.2);
    border-color: var(--k-gold);
  }

  .stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, transparent, rgba(255,255,255,0.05), transparent);
    transform: translateX(-100%);
    transition: 0.5s;
  }

  .stat-card:hover::before {
    transform: translateX(100%);
  }

  .stat-icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    color: var(--k-blue);
    transition: var(--transition);
  }

  .stat-card:hover .stat-icon {
    transform: scale(1.1) rotate(5deg);
    color: var(--k-gold);
  }

  .stat-number {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
    color: var(--k-gold);
  }

  .stat-label {
    font-size: 1rem;
    color: var(--k-text);
    opacity: 0.8;
  }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><i class="fas fa-book-reader me-2"></i>E-Library</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="login.php"><i class="fas fa-sign-in-alt me-2"></i>LOGIN</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Carousel Section -->
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="media/Bg.png" class="d-block w-100" alt="Library">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="animate__animated animate__fadeInDown">Welcome to E-Library</h5>
        <p class="animate__animated animate__fadeInUp">A gateway to knowledge anytime, anywhere.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="media/Bg.png" class="d-block w-100" alt="Reading">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="animate__animated animate__fadeInDown">Digital Collection</h5>
        <p class="animate__animated animate__fadeInUp">Access thousands of eBooks and resources.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="media/Bg.png" class="d-block w-100" alt="Knowledge">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="animate__animated animate__fadeInDown">Your Reading Journey</h5>
        <p class="animate__animated animate__fadeInUp">Track your progress and reading history.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>

<!-- Welcome Section -->
<div class="container my-4 text-center">
  <h1 class="display-5 animate__animated animate__fadeInDown">Welcome to the E-Library</h1>
  <p class="lead animate__animated animate__fadeIn animate__delay-1s typing-text">
    Discover a world of knowledge at your fingertips
  </p>

  <!-- Statistics Section -->
  <div class="row justify-content-center my-5">
    <div class="col-md-4 mb-4">
      <div class="stat-card">
        <i class="fas fa-book stat-icon"></i>
        <div class="stat-number"><?php echo $total_books; ?></div>
        <div class="stat-label">Total Books</div>
      </div>
    </div>
    <div class="col-md-4 mb-4">
      <div class="stat-card">
        <i class="fas fa-tags stat-icon"></i>
        <div class="stat-number"><?php echo $total_categories; ?></div>
        <div class="stat-label">Book Categories</div>
      </div>
    </div>
    <div class="col-md-4 mb-4">
      <div class="stat-card">
        <i class="fas fa-users stat-icon"></i>
        <div class="stat-number"><?php echo $total_users; ?></div>
        <div class="stat-label">Active Readers</div>
      </div>
    </div>
  </div>

  <!-- Search Bar -->
  <!-- <div class="search-container d-flex justify-content-center my-4 animate__animated animate__fadeInUp animate__delay-2s">
    <div class="position-relative w-50">
      <input class="form-control" type="search" placeholder="Search books, authors..." aria-label="Search">
      <i class="fas fa-search search-icon"></i>
    </div>
    <button class="btn btn-primary ms-2" type="submit">Search</button>
  </div>
</div>  -->

<!-- Dashboard Cards -->
<div class="container">
  <div class="row text-center">
    <div class="col-md-12 mb-6 animate__animated animate__zoomIn animate__delay-2s">
      <div class="card card-hover shadow-sm pulse">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-user-circle me-2"></i>LOGIN</h5>
          <p class="card-text">MULAI MEMBACA</p>
          <a href="login.php" class="btn btn-primary">
            <i class="fas fa-sign-in-alt me-2"></i>MASUK
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Floating Action Button -->
<a href="#" class="floating-btn" title="Back to Top">
  <i class="fas fa-arrow-up"></i>
</a>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Add smooth scrolling for the floating button
document.querySelector('.floating-btn').addEventListener('click', function(e) {
  e.preventDefault();
  window.scrollTo({top: 0, behavior: 'smooth'});
});

// Add typing animation effect
const text = document.querySelector('.typing-text');
text.style.width = '0';
setTimeout(() => {
  text.style.width = '100%';
}, 100);
</script>

</body>
</html>

