<?php
    include ("koneksi.php");

    //fungsi menampilkan 
    function select($query){
        global $db;
        $result = mysqli_query($db, $query);
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;   
}

function create_user ($post) {
    global $db;

    $name = strip_tags($post['name']);
    $username = strip_tags($post['username']);
    $password = strip_tags($post['password']);
    $level = "user";
    $status = "Aktif";

    // Query menyebutkan kolom yang diisi (kecuali kolom 'id')
    $query = "INSERT INTO login (name, username, password, level, status) VALUES ('$name', '$username', '$password', '$level' , '$status')";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}

function create_login ($post) {
    global $db;

    $name = strip_tags($post['name']);
    $username = strip_tags($post['username']);
    $password = strip_tags($post['password']);
    $level = strip_tags($post['level']);
    $status = strip_tags($post['status']);

    // Query menyebutkan kolom yang diisi (kecuali kolom 'id')
    $query = "INSERT INTO login (name, username, password, level, status) VALUES ('$name', '$username', '$password', '$level', '$status')";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}
    //kita akan lakukan hal yang sama untuk functi0n edit user haha cuman kita ganti beberapa sintaks
    function ubah_login ($post){
        global $db;
        $id = $post['id'];
        $name = strip_tags($post ['name']);
        $username = strip_tags($post ['username']);
        $password = strip_tags($post ['password']);
        $level = strip_tags($post ['level']);
        $status = strip_tags($post ['status']);

        //Querries untuk intinya ngedit datanya lah ya 
        $query  = "UPDATE login SET name ='$name', username ='$username', password ='$password', level ='$level', status= '$status' WHERE id=$id" ;
        mysqli_query( $db, $query ) ;   
        return mysqli_affected_rows($db);
    }

    //fungsi buat hapus user
    function delete_login($id): int|string {
        global $db;
        
        // Query untuk menghapus user berdasarkan ID yang secara otomatis dibuat karena auto increment 
        $query = "DELETE FROM login WHERE id=$id";
        
        mysqli_query(mysql: $db, query: $query);
        return mysqli_affected_rows(mysql: $db);
    }

    function create_cate ($post) {
        global $db;
    
        $nama_kategori = strip_tags($post['nama_kategori']);
    
        // Query menyebutkan kolom yang diisi (kecuali kolom 'id')
        $query = "INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')";
    
        mysqli_query($db, $query);
    
        return mysqli_affected_rows($db);
    }

    function ubah_cate ($post){
        global $db;
        $id_kategori = $post['id_kategori'];
        $nama_kategori = strip_tags($post ['nama_kategori']);

        //Querries untuk intinya ngedit datanya lah ya , dan kita akan menggunakan  untuk it
        $query  = "UPDATE kategori SET nama_kategori ='$nama_kategori' WHERE id_kategori = $id_kategori" ;
        mysqli_query( $db, $query ) ;   
        return mysqli_affected_rows($db);
    }     
    
    function delete_cate($id_kategori): int|string {
        global $db;
        
        
        $query = "DELETE FROM kategori WHERE id_kategori=$id_kategori";
        
        mysqli_query(mysql: $db, query: $query);
        return mysqli_affected_rows(mysql: $db);
    }

    function create_book ($post) {
        global $db;
    
        $pengguna = $_SESSION['username'] ?? 'UNKNOWN';

        $id_kategori = strip_tags($post['id_kategori']);
        $judul_buku = strip_tags($post['judul_buku']);
        $pengarang = strip_tags($post['pengarang']);
        $tahun_terbit = strip_tags($post['tahun_terbit']);
        $jumlah_buku = strip_tags($post['jumlah_buku']);
        $deskripsi = strip_tags($post['deskripsi']);
        $cover = strip_tags($post['cover']);

        // Query menyebutkan kolom yang diisi (kecuali kolom 'id')
        $query = "INSERT INTO buku (id_kategori, judul_buku, pengarang, tahun_terbit, deskripsi, cover, jumlah_buku) VALUES ('$id_kategori', '$judul_buku', '$pengarang' , '$tahun_terbit', '$deskripsi', '$cover', '$jumlah_buku')";
    
        if (mysqli_query($db, $query)) {
            $last_id = mysqli_insert_id($db);

            // Check if this action was already logged
            $check_log = "SELECT * FROM log_aktivitas WHERE aksi = 'INSERT' AND tabel = 'buku' AND id_terkait = '$last_id' AND pengguna = '$pengguna'";
            $log_result = mysqli_query($db, $check_log);
            
            if (mysqli_num_rows($log_result) == 0) {
                $log = "INSERT INTO log_aktivitas (aksi, tabel, id_terkait, pengguna)
                        VALUES ('INSERT', 'buku', '$last_id', '$pengguna')";
                mysqli_query($db, $log);
            }

            return mysqli_affected_rows($db);
        }

        return 0;
    }

    function ubah_buku($post){
        global $db;
        $id_buku = $post['id_buku'];
        $id_kategori = strip_tags($post['id_kategori']);
        $judul_buku = strip_tags($post['judul_buku']);
        $pengarang = strip_tags($post['pengarang']);
        $tahun_terbit = strip_tags($post['tahun_terbit']);
        $deskripsi = strip_tags($post['deskripsi']);
        $cover = strip_tags($post['cover']);
        $jumlah_buku = strip_tags($post['jumlah_buku']);

        //Querries untuk intinya ngedit datanya lah ya 
        $query  = "UPDATE buku SET id_kategori ='$id_kategori', judul_buku ='$judul_buku', pengarang ='$pengarang', tahun_terbit = '$tahun_terbit', deskripsi = '$deskripsi' , cover = '$cover'   ,jumlah_buku = '$jumlah_buku' WHERE id_buku=$id_buku" ;
        mysqli_query( $db, $query ) ;   
        return mysqli_affected_rows($db);
    }
    function delete_book($id): int|string {
        global $db;
        
        $query = "DELETE FROM buku WHERE id_buku= $id";
        
        mysqli_query(mysql: $db, query: $query);
        return mysqli_affected_rows(mysql: $db);
    }
    