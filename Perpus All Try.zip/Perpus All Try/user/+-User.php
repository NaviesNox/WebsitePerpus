<?php
include("../config/controller.php");
if (isset($_POST['tambahUserBaru'])) {
    if (create_user($_POST) > 0) { 
        echo "<script>alert('Data Berhasil Ditambahkan'); document.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Data Gagal Ditambahkan'); document.location.href='index.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menambah User Baru</title>
    <link rel="stylesheet" href="..\node_modules\bootstrap\dist\css\bootstrap.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">

    <style>
        :root {
            --k-primary: #ed1c24;    /* KYT Red */
            --k-black: #000000;      /* Black */
            --k-dark: #2c2c2c;       /* Card/section BG */
            --k-gray: #393e46;       /* Nav/secondary BG */
            --k-light: #f3f4f6;      /* Table stripes, light BG */
            --k-white: #ffffff;      /* White */
            --k-blue: #00adb5;       /* Accent Blue */
            --k-gold: #f6c700;       /* Gold accent */
            --k-text: #fdfbf7;       /* Off-white text */
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        body {
            margin: 0;
            height: 100vh;
            background: var(--k-black);
            color: var(--k-text);
            font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .kembali-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 999;
            color: var(--k-white);
            text-decoration: none;
        }
        .kembali-btn:hover {
            color: var(--k-gold);
        }
        .card {
            background: var(--k-dark) !important;
            color: var(--k-text) !important;
            border: 2px solid var(--k-primary);
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(237, 28, 36, 0.15);
            transition: var(--transition);
        }
        .card:hover {
            box-shadow: 0 0 25px rgba(237,28,36,0.3);
        }
        .form-control {
            background-color: var(--k-gray);
            color: var(--k-white);
            border: 1px solid var(--k-blue);
            transition: var(--transition);
        }
        .form-control:focus {
            border-color: var(--k-blue);
            box-shadow: 0 0 10px var(--k-blue);
        }
        .form-control::placeholder {
            color: #b0b0b0;
        }
        .btn-dark {
            background-color: var(--k-primary) !important;
            color: var(--k-white) !important;
            border: none;
            transition: var(--transition);
        }
        .btn-dark:hover {
            background-color: var(--k-gold) !important;
            color: var(--k-black) !important;
        }
        .btn {
            font-weight: 600;
        }
    </style>
</head>
<body>

    <a href="../index.php" class="btn btn-dark kembali-btn">Kembali</a>


    <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="card  p-4 shadow" style="width: 400px; background-color:#00ADB5 ;">
            <h3 class="text-center mb-4" style="color: white;">Tambah ACCOUNT</h3>
            <form action="" method="POST" class="text-center" style="color: white;">
                <div class="mb-3">
                    <label for="name" class="form-label">NAMA</label>
                    <input type="text" class="form-control" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="username" class="form-label">USERNAME</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">PASSWORD</label>
                    <input type="text" class="form-control" name="password" required>
                </div>
                <div class="mb-3">
                    <label for="level" class="form-label" hidden>LEVEL</label>
                    <input hidden type="text" class="form-control" name="level">
                </div>
                <div class="mb-3">
                    <label  hidden for="status" class="form-label">STATUS</label>
                    <input hidden type="text" class="form-control" name="status">
                </div>
                <button class="btn btn-dark w-100" type="submit" name="tambahUserBaru">Tambah Akun</button>
            </form>
        </div>
    </div>
    
</body>

</html>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
AOS.init();
</script>