<?php
include '../config/controller.php';

$id = (int)$_GET['id'];


if(delete_login($id)> 0){
    echo "<script>
    alert('Data Berhasil diHapus'); document.location.href='DataUser.php'; </script>";
    
}else {
    echo "<script>alert('Data Gagal Dihapus'); document.location.href='DataUser.php';</script>";
}
?>