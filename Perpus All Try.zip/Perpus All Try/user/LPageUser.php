<?php
 include("../config/controller.php");
 // function untuk memanggil SQL menampilkan
 $data_buku = select("SELECT buku.*, kategori.nama_kategori 
          FROM buku 
          LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Form</title>
     <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</head>
<style>
    :root {
        --k-primary: #2c3e50;    /* Deep Blue */
        --k-black: #1a1a1a;      /* Darker Background */
        --k-dark: #34495e;       /* Card/section BG */
        --k-gray: #7f8c8d;       /* Nav/secondary BG */
        --k-light: #ecf0f1;      /* Table stripes, light BG */
        --k-white: #ffffff;      /* White */
        --k-blue: #3498db;       /* Accent Blue */
        --k-gold: #f1c40f;       /* Warm Gold */
        --k-text: #ecf0f1;       /* Off-white text */
        --k-accent: #e74c3c;     /* Accent Red */
        --k-success: #2ecc71;    /* Success Green */
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        background: var(--k-black);
        color: var(--k-text);
        font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
        margin: 0;
        padding-top: 60px;
    }

    /* Navigation */
    nav {
        background-color: var(--k-primary) !important;
        text-align: center;
        margin: 0;
        padding: 0;
        position: fixed;
        width: 100%;
        top: 0;
        z-index: 1000;
        box-shadow: 0 2px 20px rgba(0,0,0,0.1);
    }

    nav ul {
        padding: 0;
        margin: 0;
    }

    nav ul li {
        list-style: none;
        display: inline;
    }

    nav ul li a {
        color: var(--k-white);
        text-decoration: none;
        font-size: 1rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        transition: var(--transition);
    }

    nav ul li a:hover {
        color: var(--k-gold);
    }

    /* Sidebar */
    .w3-sidebar {
        background-color: var(--k-primary) !important;
        color: var(--k-white);
        box-shadow: 0 0 30px rgba(0,0,0,0.2);
        width: 250px !important;
    }

    .w3-bar-item {
        color: var(--k-white) !important;
        border-bottom: 1px solid var(--k-gray);
        font-family: 'Poppins', sans-serif;
        padding: 1rem 2rem !important;
        transition: var(--transition);
    }

    .w3-bar-item:hover {
        background-color: var(--k-blue) !important;
        color: var(--k-white) !important;
    }

    .w3-bar-item.w3-button {
        width: 100%;
        text-align: left;
        padding: 1rem 2rem !important;
    }

    .w3-bar-item.w3-button.w3-large {
        font-size: 1.5rem;
        padding: 1rem !important;
        text-align: center;
        background-color: var(--k-primary) !important;
        color: var(--k-white) !important;
    }

    .w3-bar-item.w3-button.w3-large:hover {
        background-color: var(--k-gold) !important;
        color: var(--k-black) !important;
    }

    /* Book Cards */
    .books-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 2rem;
        padding: 2rem 0;
    }

    .book-card {
        background: var(--k-dark);
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        transition: var(--transition);
        height: 100%;
        display: flex;
        flex-direction: column;
        border: 1px solid var(--k-blue);
    }

    .book-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(52, 152, 219, 0.2);
        border-color: var(--k-gold);
    }

    .book-cover {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-bottom: 2px solid var(--k-blue);
    }

    .book-info {
        padding: 1.5rem;
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }

    .book-title {
        color: var(--k-gold);
        font-size: 1.25rem;
        font-weight: 600;
        margin-bottom: 0.5rem;
    }

    .book-author {
        color: var(--k-blue);
        font-size: 0.9rem;
        margin-bottom: 0.5rem;
    }

    .book-year {
        color: var(--k-gray);
        font-size: 0.85rem;
        margin-bottom: 1rem;
    }

    .book-description {
        color: var(--k-text);
        font-size: 0.9rem;
        line-height: 1.5;
        margin-bottom: 1rem;
        flex-grow: 1;
    }

    .book-category {
        display: inline-block;
        background: var(--k-blue);
        color: var(--k-white);
        padding: 0.25rem 0.75rem;
        border-radius: 15px;
        font-size: 0.8rem;
        margin-bottom: 1rem;
    }

    /* Search and Filter */
    .filter-section {
        display: flex;
        justify-content: center;
        gap: 1rem;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        align-items: center;
    }

    .search-box {
        flex: 1;
        max-width: 400px;
        position: relative;
    }

    .search-input {
        width: 100%;
        padding: 0.75rem 1rem;
        padding-left: 2.5rem;
        background: var(--k-dark);
        color: var(--k-text);
        border: 1px solid var(--k-blue);
        border-radius: 20px;
        font-size: 1rem;
        transition: var(--transition);
    }

    .search-input:focus {
        outline: none;
        border-color: var(--k-gold);
        box-shadow: 0 0 15px rgba(52, 152, 219, 0.2);
    }

    .search-icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--k-blue);
    }

    .category-select {
        padding: 0.75rem 2rem 0.75rem 1rem;
        background: var(--k-dark);
        color: var(--k-text);
        border: 1px solid var(--k-blue);
        border-radius: 20px;
        font-size: 1rem;
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%23f1c40f' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 0.75rem center;
        background-size: 16px;
        transition: var(--transition);
    }

    .category-select:focus {
        outline: none;
        border-color: var(--k-gold);
        box-shadow: 0 0 15px rgba(52, 152, 219, 0.2);
    }

    .category-select option {
        background: var(--k-dark);
        color: var(--k-text);
        padding: 1rem;
    }

    .no-results {
        text-align: center;
        color: var(--k-gray);
        font-size: 1.2rem;
        padding: 2rem;
        grid-column: 1 / -1;
    }

    .section-title {
        color: var(--k-gold);
        font-size: 1.75rem;
        font-weight: 600;
        margin: 2rem 0 1.5rem;
        text-align: center;
    }

    /* Overlay */
    .w3-overlay {
        position: fixed;
        display: none;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0,0,0,0.5);
        z-index: 1000;
    }

    /* Responsive Design */
    @media screen and (max-width: 768px) {
        .books-grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
            padding: 1.5rem 0;
        }

        .filter-section {
            flex-direction: column;
            align-items: stretch;
        }

        .search-box {
            max-width: none;
        }

        .category-select {
            width: 100%;
        }
    }
</style>
<body >

<nav class="navbar navbar-expand-lg navbar-dark" style="position: fixed; top: 0; width: 100%; z-index: 1000;">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
      aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link text-white" href="#tentang">Landing</a>
        <span class="nav-link disabled text-white">|</span>
        <a class="nav-link text-white" href="#">Page</a>
        <span class="nav-link disabled text-white">|</span>
        <a class="nav-link text-white" href="#">Siswa</a>
        <span class="nav-link disabled text-white">|</span>
       
      </div>
       
    </div>
     <a class="nav-link text-white fa fa-bars" href="#" onclick="w3_open()"></a>
  </div>
</nav>

<!-- Sidebar -->
<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none; z-index: 1001;" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large" onclick="w3_close()">Close &times;</button>
  <a href="../index.php" class="w3-bar-item w3-button">Logout</a>
</div>

<!-- Overlay -->
<div class="w3-overlay w3-animate-opacity" onclick="w3_close()" style="cursor:pointer; display:none;" id="myOverlay"></div>

<div id="main" class="container" style="margin-top: 80px;">
    <h2 class="section-title">Book Collection</h2>
    
    <!-- Replace filter buttons with search and dropdown -->
    <div class="filter-section">
        <div class="search-box">
            <i class="fas fa-search search-icon"></i>
            <input type="text" class="search-input" placeholder="Search by title, author, year, or category..." id="searchInput">
        </div>
        <select class="category-select" id="categoryFilter">
            <option value="all">All Categories</option>
            <?php
            $categories = array_unique(array_column($data_buku, 'nama_kategori'));
            foreach($categories as $category): ?>
                <option value="<?= htmlspecialchars($category); ?>">
                    <?= htmlspecialchars($category); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="books-grid">
        <?php foreach($data_buku as $book): ?>
            <div class="book-card" 
                 data-category="<?= htmlspecialchars($book['nama_kategori']); ?>"
                 data-title="<?= htmlspecialchars($book['judul_buku']); ?>"
                 data-author="<?= htmlspecialchars($book['pengarang']); ?>"
                 data-year="<?= htmlspecialchars($book['tahun_terbit']); ?>">
                <img src="<?= !empty($book['cover']) ? $book['cover'] : 'https://via.placeholder.com/300x200?text=No+Cover' ?>" 
                     alt="<?= htmlspecialchars($book['judul_buku']); ?>" 
                     class="book-cover">
                <div class="book-info">
                    <span class="book-category"><?= htmlspecialchars($book['nama_kategori']); ?></span>
                    <h3 class="book-title"><?= htmlspecialchars($book['judul_buku']); ?></h3>
                    <p class="book-author">By <?= htmlspecialchars($book['pengarang']); ?></p>
                    <p class="book-year">Published: <?= htmlspecialchars($book['tahun_terbit']); ?></p>
                    <p class="book-description"><?= !empty($book['deskripsi']) ? htmlspecialchars($book['deskripsi']) : 'No description available.'; ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Add Font Awesome for search icon -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<!-- Updated JavaScript for search and filter -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const categoryFilter = document.getElementById('categoryFilter');
        const bookCards = document.querySelectorAll('.book-card');
        const booksGrid = document.querySelector('.books-grid');

        function filterBooks() {
            const searchTerm = searchInput.value.toLowerCase();
            const selectedCategory = categoryFilter.value;
            let hasResults = false;

            bookCards.forEach(card => {
                const title = card.getAttribute('data-title').toLowerCase();
                const author = card.getAttribute('data-author').toLowerCase();
                const year = card.getAttribute('data-year').toLowerCase();
                const category = card.getAttribute('data-category').toLowerCase();
                
                const matchesSearch = title.includes(searchTerm) || 
                                    author.includes(searchTerm) || 
                                    year.includes(searchTerm) || 
                                    category.includes(searchTerm);
                
                const matchesCategory = selectedCategory === 'all' || 
                                      card.getAttribute('data-category') === selectedCategory;

                if (matchesSearch && matchesCategory) {
                    card.style.display = 'flex';
                    card.style.animation = 'fadeIn 0.5s ease-in-out';
                    hasResults = true;
                } else {
                    card.style.display = 'none';
                }
            });

            // Show/hide no results message
            let noResults = document.querySelector('.no-results');
            if (!hasResults) {
                if (!noResults) {
                    noResults = document.createElement('div');
                    noResults.className = 'no-results';
                    noResults.textContent = 'No books found matching your search criteria.';
                    booksGrid.appendChild(noResults);
                }
            } else if (noResults) {
                noResults.remove();
            }
        }

        // Add event listeners
        searchInput.addEventListener('input', filterBooks);
        categoryFilter.addEventListener('change', filterBooks);
    });

    // Sidebar functions
    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }

    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }

    // Close sidebar when clicking outside
    document.addEventListener('click', function(event) {
        const sidebar = document.getElementById('mySidebar');
        const overlay = document.getElementById('myOverlay');
        const menuButton = document.querySelector('.nav-link[onclick="w3_open()"]');
        
        if (sidebar.style.display === 'block' && 
            !sidebar.contains(event.target) && 
            !menuButton.contains(event.target)) {
            w3_close();
        }
    });
</script>
</body>
</html>