<?php
    include("../config/controller.php");
    // function untuk memanggil SQL menampilkan data yang level-nya user
    $data_user = select("SELECT * FROM login WHERE level = 'petugas'");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Data Petugas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</head>
<style>
    :root {
        --k-primary: #2c3e50;    /* Deep Blue */
        --k-black: #1a1a1a;      /* Darker Background */
        --k-dark: #34495e;       /* Card/section BG */
        --k-gray: #7f8c8d;       /* Nav/secondary BG */
        --k-light: #ecf0f1;      /* Table stripes, light BG */
        --k-white: #ffffff;      /* White */
        --k-blue: #3498db;       /* Accent Blue */
        --k-gold: #f1c40f;       /* Warm Gold */
        --k-text: #ecf0f1;       /* Off-white text */
        --k-accent: #e74c3c;     /* Accent Red */
        --k-success: #2ecc71;    /* Success Green */
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    body {
        margin: 0;
        padding-top: 60px;
        height: 100vh;
        background: var(--k-black);
        color: var(--k-text);
        font-family: 'Poppins', Arial, sans-serif;
        animation: fadeIn 1s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    nav {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background-color: var(--k-primary) !important;
        text-align: center;
        padding: 10px 0;
        z-index: 1000;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }
    nav ul {
        padding: 0;
        margin: 0;
    }
    nav ul li {
        list-style: none;
        display: inline;
    }
    nav ul li a {
        color: var(--k-white);
        text-decoration: none;
        padding: 10px 15px;
        transition: var(--transition);
    }
    nav ul li a:hover {
        background-color: var(--k-gold);
        color: var(--k-primary);
    }
    #table-data {
        background-color: var(--k-dark);
        color: var(--k-text);
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    .table {
        background-color: var(--k-dark);
        color: var(--k-text);
    }
    .table-responsive {
        background-color: var(--k-dark);
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        color: var(--k-text);
        font-size: 14px;
    }
    thead {
        background-color: var(--k-primary);
        color: var(--k-white);
    }
    th, td {
        padding: 0.75rem;
        text-align: left;
        vertical-align: baseline;
        border-bottom: 1px solid var(--k-gray);
    }
    tbody tr:nth-child(even) {
        background-color: rgba(52, 152, 219, 0.1);
    }
    tbody tr:hover {
        background-color: rgba(52, 152, 219, 0.2);
    }
    .btn-warning {
        background-color: var(--k-gold) !important;
        color: var(--k-primary) !important;
        border: none;
        transition: var(--transition);
    }
    .btn-warning:hover {
        background-color: var(--k-blue) !important;
        color: var(--k-white) !important;
        transform: translateY(-2px);
    }
    .btn-danger {
        background-color: var(--k-accent) !important;
        color: var(--k-white) !important;
        border: none;
        transition: var(--transition);
    }
    .btn-danger:hover {
        background-color: var(--k-gold) !important;
        color: var(--k-primary) !important;
        transform: translateY(-2px);
    }
    .btn {
        font-weight: 600;
        padding: 0.5rem 1rem;
        border-radius: 6px;
    }
    .container h1 {
        color: var(--k-gold);
        margin-bottom: 1.5rem;
        font-weight: 600;
    }
    @media screen and (max-width: 768px) {
        table, thead, tbody, th, td, tr {
            display: block;
        }
        thead {
            display: none;
        }
        tr {
            margin-bottom: 1rem;
            border: 1px solid var(--k-gray);
            border-radius: 6px;
            padding: 0.5rem;
            background-color: var(--k-dark);
        }
        td {
            text-align: right;
            padding-left: 50%;
            position: relative;
        }
        td::before {
            content: attr(data-label);
            position: absolute;
            left: 1rem;
            top: 0.75rem;
            font-weight: bold;
            text-align: left;
            color: var(--k-gold);
        }
    }
    .btn-back {
        background-color: var(--k-primary);
        color: var(--k-light);
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.3s ease;
        font-weight: 500;
        text-decoration: none;
    }

    .btn-back:hover {
        background-color: var(--k-gold);
        color: var(--k-dark);
        transform: translateY(-2px);
    }
</style>

<body>
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #00ADB5; position: fixed; top: 0; width: 100%; z-index: 1000;">
  <div class="container-fluid">
   
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
      aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link text-white" href="#tentang">MANAGE</a>
        <span class="nav-link disabled text-white">|</span>
        <a class="nav-link text-white" href="#">DATA</a>
        <span class="nav-link disabled text-white">|</span>
        <a class="nav-link text-white" href="#">ACCOUNT</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
    <h1 style="color:rgb(255, 255, 255);">DATA ACCOUNT PETUGAS</h1>
    <table>
        <th>
            <a href="../admin/LPageAdmin.php" class="btn-back">KEMBALI</a>
        </th>
    </table>
    <br><br>
    <table class="table-responsive table-hover table-bordered" id="table-data">
        <thead>
            <tr>
                <th scope="col">NO</th>
                <th scope="col">ID</th>
                <th scope="col">NAME</th>
                <th scope="col">USERNAME</th>
                <th scope="col">PASSWORD</th>
                <th scope="col">LEVEL</th>
                <th scope="col">STATUS</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach($data_user as $login): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $login['id']; ?></td>
                    <td><?= $login['name']; ?></td>
                    <td><?= $login['username']; ?></td>
                    <td><?= $login['password']; ?></td>
                    <td><?= $login['level']; ?></td>
                    <td><?= $login['status']; ?></td>
                    <td>
                        <button class="btn btn-warning">
                            <a style="text-decoration: none; color: white;" href="../user/UbahUser.php?id=<?= $login['id']; ?>" class="edit-btn">Edit</a>
                        </button>   
                        <button class="btn btn-danger">
                            <a style="text-decoration: none; color: white;" href="../user/HapusUser.php?id=<?= $login['id']; ?>" class="delete-btn" onclick="return confirm('Apakah Anda yakin akan Menghapus Data Ini?')">Hapus</a>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
