<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page Siswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --k-primary: #2c3e50;    /* Deep Blue */
            --k-black: #1a1a1a;      /* Darker Background */
            --k-dark: #34495e;       /* Card/section BG */
            --k-gray: #7f8c8d;       /* Nav/secondary BG */
            --k-light: #ecf0f1;      /* Table stripes, light BG */
            --k-white: #ffffff;      /* White */
            --k-blue: #3498db;       /* Accent Blue */
            --k-gold: #f1c40f;       /* Warm Gold */
            --k-text: #ecf0f1;       /* Off-white text */
            --k-accent: #e74c3c;     /* Accent Red */
            --k-success: #2ecc71;    /* Success Green */
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        body {
            background: var(--k-black);
            color: var(--k-text);
            font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
        }
        nav {
            background-color: var(--k-primary) !important;
            text-align: center;
            margin: 0;
            padding: 0;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }

        nav ul {
            padding: 0;
            margin: 0;
        }

        nav ul li {
            list-style: none;
            display: inline;
        }

        nav ul li a {
            color: var(--k-white);
            text-decoration: none;
            font-size: 1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: var(--transition);
        }

        nav ul li a:hover {
            color: var(--k-gold);
        }

        .hover-card {
            transition: var(--transition);
            border-radius: 15px;
            background: var(--k-dark);
            color: var(--k-text);
            border: 1px solid var(--k-blue);
        }

        .hover-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.2);
            border-color: var(--k-gold);
        }
        .card {
            background: var(--k-dark) !important;
            color: var(--k-text) !important;
            border: 1px solid var(--k-blue);
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            transition: var(--transition);
        }
        .card:hover {
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.2);
            border-color: var(--k-gold);
        }
        .btn-light {
            background-color: var(--k-blue) !important;
            color: var(--k-white) !important;
            border: none;
            transition: var(--transition);
        }
        .btn-light:hover {
            background-color: var(--k-gold) !important;
            color: var(--k-primary) !important;
        }
        .form-control {
            background-color: var(--k-dark);
            color: var(--k-text);
            border: 1px solid var(--k-blue);
            transition: var(--transition);
        }
        .form-control:focus {
            border-color: var(--k-gold);
            box-shadow: 0 0 15px rgba(52, 152, 219, 0.2);
        }
        .form-control::placeholder {
            color: var(--k-gray);
        }
        .dashboard-header {
            background: linear-gradient(135deg, var(--k-primary), var(--k-dark));
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-bottom: 4px solid var(--k-gold);
        }

        .stat-card {
            background: var(--k-dark);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid var(--k-blue);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.2);
            border-color: var(--k-gold);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.05), transparent);
            transform: translateX(-100%);
            transition: 0.5s;
        }

        .stat-card:hover::before {
            transform: translateX(100%);
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--k-blue);
            transition: var(--transition);
        }

        .stat-card:hover .stat-icon {
            transform: scale(1.1) rotate(5deg);
            color: var(--k-gold);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
            color: var(--k-gold);
        }

        .stat-label {
            font-size: 1rem;
            color: var(--k-text);
            opacity: 0.8;
        }

        .action-card {
            background: var(--k-dark);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid var(--k-blue);
            transition: var(--transition);
            cursor: pointer;
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.2);
            background: var(--k-primary);
            border-color: var(--k-gold);
        }

        .action-card:hover .card-icon {
            color: var(--k-gold) !important;
        }

        .action-card:hover .card-title,
        .action-card:hover .card-text {
            color: var(--k-white) !important;
        }

        .card-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--k-blue);
            transition: var(--transition);
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
            color: var(--k-text);
        }

        .card-text {
            font-size: 0.9rem;
            color: var(--k-text);
            opacity: 0.8;
        }

        .w3-sidebar {
            background-color: var(--k-primary) !important;
            color: var(--k-white);
            box-shadow: 0 0 30px rgba(0,0,0,0.2);
        }

        .w3-bar-item {
            color: var(--k-white) !important;
            border-bottom: 1px solid var(--k-gray);
            font-family: 'Poppins', sans-serif;
            padding: 1rem 2rem !important;
            transition: var(--transition);
        }

        .w3-bar-item:hover {
            background-color: var(--k-blue) !important;
            color: var(--k-white) !important;
        }

        .search-container {
            position: relative;
            max-width: 300px;
        }

        .search-container input {
            background: var(--k-dark);
            border: 1px solid var(--k-blue);
            color: var(--k-text);
            padding-right: 40px;
            border-radius: 20px;
        }

        .search-container input:focus {
            box-shadow: 0 0 15px rgba(52, 152, 219, 0.2);
            border-color: var(--k-gold);
        }

        .search-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--k-blue);
        }

        .modal-content {
            background-color: var(--k-dark);
            color: var(--k-text);
            border: 1px solid var(--k-blue);
        }

        .modal-header {
            border-bottom: 1px solid var(--k-blue);
        }

        .modal-footer {
            border-top: 1px solid var(--k-blue);
        }

        .btn-primary {
            background-color: var(--k-blue);
            border-color: var(--k-blue);
        }

        .btn-primary:hover {
            background-color: var(--k-gold);
            border-color: var(--k-gold);
            color: var(--k-primary);
        }

        .floating-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: var(--k-blue);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--k-white);
            font-size: 24px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            transition: var(--transition);
            z-index: 1000;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.5s ease-out forwards;
            animation-delay: 1s;
        }

        .floating-btn:hover {
            transform: translateY(-5px) rotate(360deg);
            background: var(--k-gold);
            color: var(--k-primary);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
<nav>
        <ul> 
            <li style="color: white;">|</li>
            <li>
              <a href="#tentang">LANDING</a>
            </li>
            <li style="color: white;">|</li>
            
            
            <li>
                <a href="#">PAGE</a>
            </li>
            <li style="color: white;">|</li>  
            
            <li>
                <a href="#">PETUGAS</a>
            </li>

            <li style="color: white;">|</li>
            
        </ul> 
    </nav>
    
    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Close &times;</button>
  <a href="../index.php" class="w3-bar-item w3-button">LOG OUT</a>

</div>

<div id="main">

<div class="d-flex justify-content-between align-items-center p-3" 
     style="background-color: #00ADB5; position: relative;">
  
    <button id="openNav" class="w3-button w3-xlarge" onclick="w3_open()">&#9776;</button>
    <h1 class="m-0 text-white">PETUGAS PAGE</h1>

    <!-- Search Bar -->
    <form class="d-flex ms-auto" role="search">
        <input class="form-control me-2" type="search" placeholder="Search..." aria-label="Search">
        <button class="btn btn-light" type="submit">Search</button>
    </form>
</div>

    <h1 style="text-align: center;"">SELAMAT DATANG</h1>

    <!-- Card Section -->
<div class="container my-5">
  <div class="row row-cols-1 row-cols-md-3 g-4">

    <!-- Card 1 -->
    <div class="col">
      <div class="card text-center shadow-lg border-0 p-3 hover-card" onclick="location.href='DataSiswaPt.php'" style="cursor:pointer;">
        <div class="card-body">
          <i class="fas fa-user-graduate fa-3x mb-3 text-primary"></i>
          <h5 class="card-title">Data Siswa</h5>
          <p class="card-text">Kelola data siswa yang terdaftar.</p>
        </div>
      </div>
    </div>

    <!-- Card 2 -->
    <div class="col">
      <div class="card text-center shadow-lg border-0 p-3 hover-card" onclick="location.href='DataP2.php'" style="cursor:pointer;">
        <div class="card-body">
          <i class="fas fa-user-tie fa-3x mb-3 text-success"></i>
          <h5 class="card-title">Data Petugas</h5>
          <p class="card-text">Informasi dan manajemen petugas.</p>
        </div>
      </div>
    </div>

    <!-- Card 3 -->
    <div class="col">
      <div class="card text-center shadow-lg border-0 p-3 hover-card" onclick="location.href='dataUsAdmin.php'" style="cursor:pointer;">
        <div class="card-body">
          <i class="fas fa-users-cog fa-3x mb-3 text-warning"></i>
          <h5 class="card-title">Kelola Akun</h5>
          <p class="card-text">Tambah atau ubah akun pengguna.</p>
        </div>
      </div>
    </div>

  </div>
</div>


</body>

<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}

function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}


</script>
</html>