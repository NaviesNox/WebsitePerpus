<?php
include("../config/controller.php");

// Fungsi untuk mengambil id user
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    
    // Ambil data user berdasarkan id
    $query = "SELECT * FROM kategori WHERE id_kategori = $id";
    $result = mysqli_query($db, $query);
    
    // Cek jika ada hasil dari query
    if (mysqli_num_rows($result) > 0) {
        // Ambil data sebagai array asosiatif
        $cate = mysqli_fetch_assoc($result);
    } else {
        echo "kategori tidak ditemukan";
        exit;
    }
}

if (isset($_POST['ubah'])) {
    if (ubah_cate($_POST) > 0) {
        echo "<script>
            alert('Data Berhasil diubah'); 
            document.location.href='CateForm.php';
        </script>";
    } else {
        echo "<script>
            alert('Data Gagal diubah'); 
            document.location.href='CateForm.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="..\node_modules\bootstrap\dist\css\bootstrap.min.css">
    <style>
    :root {
        --k-primary: #2c3e50;    /* Deep Blue */
        --k-black: #1a1a1a;      /* Darker Background */
        --k-dark: #34495e;       /* Card/section BG */
        --k-gray: #7f8c8d;       /* Nav/secondary BG */
        --k-light: #ecf0f1;      /* Table stripes, light BG */
        --k-white: #ffffff;      /* White */
        --k-blue: #3498db;       /* Accent Blue */
        --k-gold: #f1c40f;       /* Warm Gold */
        --k-text: #ecf0f1;       /* Off-white text */
        --k-accent: #e74c3c;     /* Accent Red */
        --k-success: #2ecc71;    /* Success Green */
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    body {
        margin: 0;
        min-height: 100vh;
        background: var(--k-black);
        color: var(--k-text);
        font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
        display: flex;
        flex-direction: column;
        align-items: center;
        animation: fadeIn 1s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .container {
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }
    .card-container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: calc(100vh - 100px);
        padding: 20px;
    }
    .card {
        background: var(--k-dark) !important;
        color: var(--k-text) !important;
        border: 2px solid var(--k-primary);
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        transition: var(--transition);
        width: 800px;
        padding: 2rem;
        margin: 0 auto;
    }
    .card:hover {
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        transform: translateY(-5px);
    }
    .form-control {
        background-color: var(--k-gray);
        color: var(--k-white);
        border: 1px solid var(--k-blue);
        transition: var(--transition);
        padding: 10px;
        border-radius: 6px;
    }
    .form-control:focus {
        border-color: var(--k-blue);
        box-shadow: 0 0 10px var(--k-blue);
        background-color: var(--k-dark);
    }
    .form-control::placeholder {
        color: #b0b0b0;
    }
    .form-label {
        color: var(--k-gold);
        font-weight: 600;
        margin-bottom: 8px;
    }
    .btn-dark {
        background-color: var(--k-primary) !important;
        color: var(--k-white) !important;
        border: none;
        transition: var(--transition);
        padding: 12px;
        font-weight: 600;
        border-radius: 6px;
        width: 100%;
        margin-top: 1rem;
    }
    .btn-dark:hover {
        background-color: var(--k-gold) !important;
        color: var(--k-primary) !important;
        transform: translateY(-2px);
    }
    h3 {
        color: var(--k-gold);
        font-weight: 600;
        margin-bottom: 1.5rem;
        text-align: center;
    }
    .form-row {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }
    .form-group {
        margin-bottom: 1.5rem;
    }
    .form-group.full-width {
        grid-column: 1 / -1;
    }
    </style>
</head>
<body>
    <div class="container mt-3">
        <button class="btn">
            <a href="..\category\CateForm.php" class="btn" style="color: white;">Kembali</a>
        </button>
    </div>

    <div class="card-container">
        <div class="card">
            <h3 class="text-center mb-4" style="color: white;">Edit Kategori</h3>
            <form action="" method="POST" class="text-center" style="color: white;">
                <input type="hidden" name="id_kategori" value="<?= $cate['id_kategori']; ?>">
                
                <div class="form-row">
                    <div class="form-group full-width">
                        <label for="nama" class="form-label">Nama Kategori</label>
                        <input type="text" class="form-control" name="nama_kategori" value="<?= $cate['nama_kategori']; ?>" required>
                    </div>
                </div>

                <button type="submit" name="ubah" class="btn btn-dark w-100">Ubah Category</button>
            </form>
        </div>
    </div>
</body>
</html>
