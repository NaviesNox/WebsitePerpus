<?php
include '../config/controller.php';

if (isset($_GET['id_kategori'])) {
    $id_kategori = (int)$_GET['id_kategori'];

    if(delete_cate($id_kategori) > 0){
        echo "<script>
        alert('Data Berhasil diHapus'); document.location.href='CateForm.php'; </script>";
    } else {
        echo "<script>alert('Data Gagal Dihapus'); document.location.href='CateForm.php';</script>";
    }

} else {
    // Optional fallback if id_kategori is missing
    echo "<script>alert('ID kategori tidak ditemukan.'); document.location.href='CateForm.php';</script>";
}
?>
