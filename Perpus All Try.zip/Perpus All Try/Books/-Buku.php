<?php
include '../config/controller.php';

$id = (int)$_GET['id_buku'];


if(delete_book($id)> 0){
    echo "<script>
    alert('Data Berhasil diHapus'); document.location.href='bookForm.php'; </script>";
    
}else {
    echo "<script>alert('Data Gagal Dihapus'); document.location.href='bookForm.php';</script>";
}
?>