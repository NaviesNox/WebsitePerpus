<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Prevent duplicate form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambahBuku'])) {
    include_once("../config/controller.php");
    $categoryQuery = mysqli_query($db, "SELECT * FROM kategori");

    if (create_book($_POST) > 0) { 
        echo "<script>alert('Data Berhasil Ditambahkan'); document.location.href='bookForm.php';</script>";
    } else {
        echo "<script>alert('Data Gagal Ditambahkan'); document.location.href='bookForm.php';</script>";
    }
    exit;
}

include_once("../config/controller.php");
$categoryQuery = mysqli_query($db, "SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku Baru</title>
    <link rel="stylesheet" href="..\node_modules\bootstrap\dist\css\bootstrap.min.css">
    <style>
    :root {
        --k-primary: #2c3e50;    /* Deep Blue */
        --k-black: #1a1a1a;      /* Darker Background */
        --k-dark: #34495e;       /* Card/section BG */
        --k-gray: #7f8c8d;       /* Nav/secondary BG */
        --k-light: #ecf0f1;      /* Table stripes, light BG */
        --k-white: #ffffff;      /* White */
        --k-blue: #3498db;       /* Accent Blue */
        --k-gold: #f1c40f;       /* Warm Gold */
        --k-text: #ecf0f1;       /* Off-white text */
        --k-accent: #e74c3c;     /* Accent Red */
        --k-success: #2ecc71;    /* Success Green */
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    body {
        margin: 0;
        min-height: 100vh;
        background: var(--k-black);
        color: var(--k-text);
        font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
        display: flex;
        flex-direction: column;
        align-items: center;
        animation: fadeIn 1s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .container {
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }
    .card-container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: calc(100vh - 100px);
        padding: 20px;
    }
    .container .btn {
        background-color: var(--k-primary) !important;
        color: var(--k-white) !important;
        border: none;
        transition: var(--transition);
        margin: 10px;
        padding: 8px 20px;
        border-radius: 6px;
        font-weight: 600;
    }
    .container .btn:hover {
        background-color: var(--k-gold) !important;
        color: var(--k-primary) !important;
        transform: translateY(-2px);
    }
    .card {
        background: var(--k-dark) !important;
        color: var(--k-text) !important;
        border: 2px solid var(--k-primary);
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        transition: var(--transition);
        width: 800px;
        padding: 2rem;
        margin: 0 auto;
    }
    .card:hover {
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        transform: translateY(-5px);
    }
    .form-control {
        background-color: var(--k-gray);
        color: var(--k-white);
        border: 1px solid var(--k-blue);
        transition: var(--transition);
        padding: 10px;
        border-radius: 6px;
    }
    .form-control:focus {
        border-color: var(--k-blue);
        box-shadow: 0 0 10px var(--k-blue);
        background-color: var(--k-dark);
    }
    .form-control::placeholder {
        color: #b0b0b0;
    }
    /* New styles for select dropdown */
    select.form-control {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%23f1c40f' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 10px center;
        background-size: 16px;
        padding-right: 30px;
    }
    select.form-control option {
        background-color: var(--k-dark);
        color: var(--k-text);
        padding: 12px;
    }
    select.form-control option:checked {
        background-color: var(--k-primary);
        color: var(--k-gold);
    }
    select.form-control option:hover {
        background-color: var(--k-primary);
    }
    select.form-control:focus option:checked {
        background-color: var(--k-primary);
        color: var(--k-gold);
    }
    .form-label {
        color: var(--k-gold);
        font-weight: 600;
        margin-bottom: 8px;
    }
    .btn-dark {
        background-color: var(--k-primary) !important;
        color: var(--k-white) !important;
        border: none;
        transition: var(--transition);
        padding: 12px;
        font-weight: 600;
        border-radius: 6px;
        width: 100%;
        margin-top: 1rem;
    }
    .btn-dark:hover {
        background-color: var(--k-gold) !important;
        color: var(--k-primary) !important;
        transform: translateY(-2px);
    }
    h3 {
        color: var(--k-gold);
        font-weight: 600;
        margin-bottom: 1.5rem;
        text-align: center;
    }
    .form-row {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }
    .form-group {
        margin-bottom: 1.5rem;
    }
    .form-group.full-width {
        grid-column: 1 / -1;
    }
    </style>
</head>
<body>

<div class="container mt-3">
        <button class="btn">
            <a href="..\Books\bookForm.php" class="btn" style="color: white;">Kembali</a>
        </button>
    </div>

    <div class="card-container">
        <div class="card">
            <h3 class="text-center mb-4" style="color: white;">Tambah Buku</h3>
            <form action="" method="POST" class="text-center" style="color: white;">
                <div class="form-row">
                    
                    <div class="form-group">
                        <label for="id_kategori" class="form-label">Pilih Kategori</label>
                        <select name="id_kategori" class="form-control" required>
                            <option value="" disabled selected>-- Pilih Kategori --</option>
                            <?php while($row = mysqli_fetch_assoc($categoryQuery)): ?>
                                <option value="<?= $row['id_kategori']; ?>"><?= htmlspecialchars($row['nama_kategori']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="username" class="form-label">Judul Buku</label>
                        <input type="text" class="form-control" name="judul_buku" required>
                    </div>
                    <div class="form-group">
                        <label for="password" class="form-label">Pengarang</label>
                        <input type="text" class="form-control" name="pengarang" required>
                    </div>
                    <div class="form-group">
                        <label for="level" class="form-label">Tahun Terbit</label>
                        <input type="date" class="form-control" name="tahun_terbit">
                    </div>
                    <div class="form-group">
                        <label for="deskripsi" class="form-label">Deskripsi</label>
                        <input type="text" class="form-control" name="deskripsi">
                    </div>
                    <div class="form-group">
                        <label for="cover" class="form-label">Cover Buku</label>
                        <input type="text" class="form-control" name="cover">
                    </div>
                    <div class="form-group">
                        <label for="status" class="form-label">Jumlah Buku</label>
                        <input type="text" class="form-control" name="jumlah_buku">
                    </div>
                </div>
                <button class="btn btn-dark w-100" type="submit" name="tambahBuku">Tambah Buku</button>
            </form>
        </div>
    </div>

</body>
</html>