<?php
include("../config/controller.php");

// Fungsi untuk mengambil id buku
if (isset($_GET['id_buku'])) {
    $id = (int) $_GET['id_buku'];
    
    $query = "SELECT * FROM buku WHERE id_buku = $id";
    $result = mysqli_query($db, $query);
    
    // Cek jika ada hasil dari query
    if (mysqli_num_rows($result) > 0) {
        $dataBuku = mysqli_fetch_assoc($result);
    } else {
        echo "Buku tidak ditemukan";
        exit;
    }
}

if (isset($_POST['ubah_buku'])) {
    if (ubah_buku($_POST) > 0) {
        echo "<script>
            alert('Data Berhasil diubah'); 
            document.location.href='bookForm.php';
        </script>";
    } else {
        echo "<script>
            alert('Data Gagal diubah'); 
            document.location.href='bookForm.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <link rel="stylesheet" href="..\node_modules\bootstrap\dist\css\bootstrap.min.css">
    <style>
        :root {
            --k-primary: #2c3e50;    /* Deep Blue */
            --k-black: #1a1a1a;      /* Darker Background */
            --k-dark: #34495e;       /* Card/section BG */
            --k-gray: #7f8c8d;       /* Nav/secondary BG */
            --k-light: #ecf0f1;      /* Table stripes, light BG */
            --k-white: #ffffff;      /* White */
            --k-blue: #3498db;       /* Accent Blue */
            --k-gold: #f1c40f;       /* Warm Gold */
            --k-text: #ecf0f1;       /* Off-white text */
            --k-accent: #e74c3c;     /* Accent Red */
            --k-success: #2ecc71;    /* Success Green */
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        body {
            margin: 0;
            min-height: 100vh;
            background: var(--k-black);
            color: var(--k-text);
            font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .card-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 100px);
            padding: 20px;
        }
        .card {
            background: var(--k-dark) !important;
            color: var(--k-text) !important;
            border: 2px solid var(--k-primary);
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            transition: var(--transition);
            width: 800px;
            padding: 2rem;
            margin: 0 auto;
        }
        .card:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
            transform: translateY(-5px);
        }
        .form-control {
            background-color: var(--k-gray);
            color: var(--k-white);
            border: 1px solid var(--k-blue);
            transition: var(--transition);
            padding: 10px;
            border-radius: 6px;
        }
        .form-control:focus {
            border-color: var(--k-blue);
            box-shadow: 0 0 10px var(--k-blue);
            background-color: var(--k-dark);
        }
        .form-control::placeholder {
            color: #b0b0b0;
        }
        .form-label {
            color: var(--k-gold);
            font-weight: 600;
            margin-bottom: 8px;
        }
        .btn-dark {
            background-color: var(--k-primary) !important;
            color: var(--k-white) !important;
            border: none;
            transition: var(--transition);
            padding: 12px;
            font-weight: 600;
            border-radius: 6px;
            width: 100%;
            margin-top: 1rem;
        }
        .btn-dark:hover {
            background-color: var(--k-gold) !important;
            color: var(--k-primary) !important;
            transform: translateY(-2px);
        }
        h3 {
            color: var(--k-gold);
            font-weight: 600;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        .container .btn {
            background-color: var(--k-primary) !important;
            color: var(--k-white) !important;
            border: none;
            transition: var(--transition);
            margin: 10px;
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 600;
        }
        .container .btn:hover {
            background-color: var(--k-gold) !important;
            color: var(--k-primary) !important;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container mt-3">
        <button class="btn">
            <a href="bookForm.php" class="btn" style="color: white;">Kembali</a>
        </button>
    </div>

    <div class="card-container">
        <div class="card">
            <h3 class="text-center mb-4">Edit Buku</h3>
            <form action="" method="POST" class="text-center">
                <input type="hidden" name="id_buku" value="<?= $dataBuku['id_buku']; ?>">
                
                <div class="form-row">
                    <div class="form-group">

                        <label for="id_kategori" class="form-label">Nama Kategori</label>
                        <select class="form-control" name="id_kategori" required>
                            <option value="">Pilih Kategori</option>
                            <?php
                            $kategoriQuery = mysqli_query($db, "SELECT * FROM kategori");
                            while ($kategori = mysqli_fetch_assoc($kategoriQuery)) :
                                $selected = ($kategori['id_kategori'] == $dataBuku['id_kategori']) ? 'selected' : '';
                            ?>
                                <option value="<?= $kategori['id_kategori']; ?>" <?= $selected; ?>>
                                    <?= htmlspecialchars($kategori['nama_kategori']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="nama" class="form-label">Judul Buku</label>
                        <input type="text" class="form-control" name="judul_buku" value="<?=$dataBuku['judul_buku']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nama" class="form-label">Pengarang</label>
                        <input type="text" class="form-control" name="pengarang" value="<?=$dataBuku['pengarang']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nama" class="form-label">Tahun Terbit</label>
                        <input type="date" class="form-control" name="tahun_terbit" value="<?=$dataBuku['tahun_terbit']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nama" class="form-label">Deskripsi</label>
                        <input type="text" class="form-control" name="deskripsi" value="<?=$dataBuku['deskripsi']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nama" class="form-label">Cover</label>
                        <input type="text" class="form-control" name="cover" value="<?=$dataBuku['cover']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nama" class="form-label">Jumlah Buku</label>
                        <input type="text" class="form-control" name="jumlah_buku" value="<?=$dataBuku['jumlah_buku']; ?>" required>
                    </div>
                </div>
                <button type="submit" name="ubah_buku" class="btn btn-dark w-100">Ubah Buku</button>
            </form>
        </div>
    </div>
</body>
</html>
