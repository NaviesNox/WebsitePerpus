<?php
include '../config/controller.php';

// Get current logged in user's name
$current_user = $_SESSION['username'] ?? 'Unknown User';

$query = "SELECT * FROM log_aktivitas ORDER BY waktu DESC";
$result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Log Aktivitas</title>
     <link rel="stylesheet" href="..\node_modules\bootstrap\dist\css\bootstrap.min.css">

    <style>
    :root {
        --k-primary: #2c3e50;    /* Deep Blue */
        --k-black: #1a1a1a;      /* Darker Background */
        --k-dark: #34495e;       /* Card/section BG */
        --k-gray: #7f8c8d;       /* Nav/secondary BG */
        --k-light: #ecf0f1;      /* Table stripes, light BG */
        --k-white: #ffffff;      /* White */
        --k-blue: #3498db;       /* Accent Blue */
        --k-gold: #f1c40f;       /* Warm Gold */
        --k-text: #ecf0f1;       /* Off-white text */
        --k-accent: #e74c3c;     /* Accent Red */
        --k-success: #2ecc71;    /* Success Green */
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    body {
        margin: 0;
        padding-top: 60px;
        height: 100vh;
        background: var(--k-black);
        color: var(--k-text);
        font-family: 'Poppins', Arial, sans-serif;
        animation: fadeIn 1s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    nav {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background-color: var(--k-primary) !important;
        text-align: center;
        padding: 10px 0;
        z-index: 1000;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }
    nav ul {
        padding: 0;
        margin: 0;
    }
    nav ul li {
        list-style: none;
        display: inline;
    }
    nav ul li a {
        color: var(--k-white);
        text-decoration: none;
        padding: 10px 15px;
        transition: var(--transition);
    }
    nav ul li a:hover {
        background-color: var(--k-gold);
        color: var(--k-primary);
    }
    #table-data {
        background-color: var(--k-dark);
        color: var(--k-text);
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    .table {
        background-color: var(--k-dark);
        color: var(--k-text);
    }
    .table-responsive {
        background-color: var(--k-dark);
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        color: var(--k-text);
        font-size: 14px;
    }
    thead {
        background-color: var(--k-primary);
        color: var(--k-white);
    }
    th, td {
        padding: 0.75rem;
        text-align: left;
        vertical-align: baseline;
        border-bottom: 1px solid var(--k-gray);
    }
    tbody tr:nth-child(even) {
        background-color: rgba(52, 152, 219, 0.1);
    }
    tbody tr:hover {
        background-color: rgba(52, 152, 219, 0.2);
    }
    .btn-warning {
        background-color: var(--k-gold) !important;
        color: var(--k-primary) !important;
        border: none;
        transition: var(--transition);
    }
    .btn-warning:hover {
        background-color: var(--k-blue) !important;
        color: var(--k-white) !important;
        transform: translateY(-2px);
    }
    .btn-danger {
        background-color: var(--k-accent) !important;
        color: var(--k-white) !important;
        border: none;
        transition: var(--transition);
    }
    .btn-danger:hover {
        background-color: var(--k-gold) !important;
        color: var(--k-primary) !important;
        transform: translateY(-2px);
    }
    .btn {
        font-weight: 600;
        padding: 0.5rem 1rem;
        border-radius: 6px;
    }
    .container h1 {
        color: var(--k-gold);
        margin-bottom: 1.5rem;
        font-weight: 600;
    }
    @media screen and (max-width: 768px) {
        table, thead, tbody, th, td, tr {
            display: block;
        }
        thead {
            display: none;
        }
        tr {
            margin-bottom: 1rem;
            border: 1px solid var(--k-gray);
            border-radius: 6px;
            padding: 0.5rem;
            background-color: var(--k-dark);
        }
        td {
            text-align: right;
            padding-left: 50%;
            position: relative;
        }
        td::before {
            content: attr(data-label);
            position: absolute;
            left: 1rem;
            top: 0.75rem;
            font-weight: bold;
            text-align: left;
            color: var(--k-gold);
        }
    }
    .btn-back {
        background-color: var(--k-primary);
        color: var(--k-light);
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.3s ease;
        font-weight: 500;
        text-decoration: none;
    }

    .btn-back:hover {
        background-color: var(--k-gold);
        color: var(--k-dark);
        transform: translateY(-2px);
    }
</style>
</head>
<body>
   <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #00ADB5; position: fixed; top: 0; width: 100%; z-index: 1000;">
  <div class="container-fluid">
   
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
      aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link text-white" href="#tentang">AKTIFITAS</a>
        <span class="nav-link disabled text-white">|</span>
        <a class="nav-link text-white" href="#">YANG</a>
        <span class="nav-link disabled text-white">|</span>
        <a class="nav-link text-white" href="#">TERJADI</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
    <h1 style="color:rgb(255, 255, 255);">DATA AKTIFITAS</h1>
    <table>
        <th>
            <a href="LPageAdmin.php" class="btn-back">KEMBALI</a>
        </th>
    </table>
    <br><br>

    <h2>Log Aktivitas</h2>
    <table>
        <thead>
            <tr>
                <th>ID Log</th>
                <th>Aksi</th>
                <th>Tabel</th>
                <th>ID Terkait</th>
                <th>Waktu</th>
                <th>Pengguna</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['id_log']; ?></td>
                    <td><?= $row['aksi']; ?></td>
                    <td><?= $row['tabel']; ?></td>
                    <td><?= $row['id_terkait']; ?></td>
                    <td><?= $row['waktu']; ?></td>
                    <td><?= $row['pengguna']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
