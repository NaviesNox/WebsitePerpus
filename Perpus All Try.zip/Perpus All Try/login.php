<?php
session_start();
include "config/koneksi.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];




    $query = "SELECT * FROM login WHERE username = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if ($password == $user['password']) {
            $_SESSION['username'] = $user['username'];
            $_SESSION['level'] = $user['level'];

            if ($user['level'] == 'admin') {
                header("Location: admin/LPageAdmin.php");
            } elseif ($user['level'] == 'petugas') {
                header("Location: petugas/LPagePetugas.php");
            } elseif ($user['level'] == 'user') {
                header("Location: user/LPageUser.php");
            }
            exit;
        } else {
            $errorPass = "Password salah!";
        }
    } else {
        $errorUser = "User tidak ditemukan!";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login E-Library</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Assets\Theme.css">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- AOS & SweetAlert -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Custom CSS -->
    <style>
    :root {
      --k-primary: #2c3e50;    /* Deep Blue */
      --k-black: #1a1a1a;      /* Darker Background */
      --k-dark: #34495e;       /* Card/section BG */
      --k-gray: #7f8c8d;       /* Nav/secondary BG */
      --k-light: #ecf0f1;      /* Table stripes, light BG */
      --k-white: #ffffff;      /* White */
      --k-blue: #3498db;       /* Accent Blue */
      --k-gold: #f1c40f;       /* Warm Gold */
      --k-text: #ecf0f1;       /* Off-white text */
      --k-accent: #e74c3c;     /* Accent Red */
      --k-success: #2ecc71;    /* Success Green */
      --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
      background: var(--k-black);
      color: var(--k-text);
      font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 1rem;
    }

    .login-card {
      background: var(--k-dark);
      color: var(--k-text);
      border: 2px solid var(--k-blue);
      border-radius: 15px;
      box-shadow: 0 0 20px rgba(52, 152, 219, 0.15);
      transition: var(--transition);
      position: relative;
      overflow: hidden;
      width: 100%;
      max-width: 400px;
      padding: 2rem;
      margin: 0 auto;
    }

    .login-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(45deg, transparent, rgba(255,255,255,0.05), transparent);
      transform: translateX(-100%);
      transition: 0.5s;
    }

    .login-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(52, 152, 219, 0.3);
      border-color: var(--k-gold);
    }

    .login-card:hover::before {
      transform: translateX(100%);
    }

    .form-control {
      background-color: var(--k-black);
      color: var(--k-white);
      border: 1px solid var(--k-blue);
      border-radius: 8px;
      padding: 0.8rem;
      transition: var(--transition);
    }

    .form-control:focus {
      border-color: var(--k-gold);
      box-shadow: 0 0 15px rgba(52, 152, 219, 0.3);
      background-color: var(--k-dark);
    }

    .form-control::placeholder {
      color: var(--k-gray);
    }

    .form-label {
      color: var(--k-text);
      font-weight: 500;
      margin-bottom: 0.5rem;
    }

    .link-register {
      color: var(--k-blue);
      text-decoration: none;
      transition: var(--transition);
    }

    .link-register:hover {
      color: var(--k-gold);
      text-decoration: none;
    }

    .btn-login {
      background-color: var(--k-blue);
      color: var(--k-white);
      border: none;
      border-radius: 8px;
      padding: 0.8rem;
      font-weight: 600;
      transition: var(--transition);
      position: relative;
      overflow: hidden;
    }

    .btn-login:hover {
      background-color: var(--k-gold);
      color: var(--k-primary);
      transform: translateY(-2px);
    }

    .btn-login::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      background: rgba(255,255,255,0.2);
      border-radius: 50%;
      transform: translate(-50%, -50%);
      transition: width 0.6s, height 0.6s;
    }

    .btn-login:hover::after {
      width: 300px;
      height: 300px;
    }

    .checkbox-wrapper {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-top: 0.5rem;
      color: var(--k-text);
    }

    .checkbox-wrapper input[type="checkbox"] {
      accent-color: var(--k-blue);
    }

    .login-title {
      color: var(--k-gold);
      font-weight: 700;
      margin-bottom: 1.5rem;
      text-align: center;
      font-size: 1.8rem;
    }

    .error-message {
      color: var(--k-accent);
      font-size: 0.9rem;
      margin-top: 0.5rem;
    }
    </style>
</head>
<body>

<div class="container">
    <div class="login-card" data-aos="fade-up">
        <h3 class="login-title">E-LIBRARY LOGIN</h3>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" required>
                <div class="checkbox-wrapper">
                    <input type="checkbox" id="showPassword" onclick="togglePassword()">
                    <label for="showPassword">Show Password</label>
                </div>
                <div class="mt-3">
                    <small>Belum punya akun? <a href="user/+-User.php" class="link-register">Register</a></small>
                </div>
            </div>
            <button class="btn btn-login w-100" type="submit">Login</button>
        </form>
    </div>
</div>

<?php if (isset($errorPass)): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: '<?= $errorPass ?>'
    });
</script>
<?php endif; ?>
<?php if (isset($errorUser)): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'User Tidak Ditemukan',
        text: '<?= $errorUser ?>'
    });
</script>
<?php endif; ?>

<script>
function togglePassword() {
    const passwordInput = document.getElementById("password");
    passwordInput.type = passwordInput.type === "password" ? "text" : "password";
}
AOS.init();
</script>

</body>
</html>
